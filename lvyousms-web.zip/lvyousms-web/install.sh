#!/usr/bin/env bash
set -euo pipefail

fix_script_permissions() {
  chmod +x "${ROOT_DIR}/install.sh" 2>/dev/null || true
  chmod +x "${ROOT_DIR}/uninstall.sh" 2>/dev/null || true

  if [[ -d "${ROOT_DIR}/scripts" ]]; then
    find "${ROOT_DIR}/scripts" -type f -name "*.sh" -exec chmod +x {} \; 2>/dev/null || true
  fi
}
ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
APPDIR="/opt/board-manager"
APIPORT="8000"
SCANUSER="admin"
SCANPASS="admin"
UIPASS=""
CONFIG_FILE="/etc/board-manager.conf"
OS_FAMILY="debian"

source "${ROOT_DIR}/scripts/common.sh"

usage() {
  cat <<EOF
用法:
  sudo ./install.sh install [--port 8000] [--scan-user admin] [--scan-pass admin] [--ui-pass 123456]
  sudo ./install.sh status
  sudo ./install.sh restart
  sudo ./install.sh logs
EOF
}

detect_os() {
  if [[ -f /etc/os-release ]]; then
    . /etc/os-release
    case "${ID:-}" in
      ubuntu|debian)
        OS_FAMILY="debian"
        ;;
      *)
        OS_FAMILY="debian"
        ;;
    esac
  fi
}

install_system_deps() {
  detect_os

  if [[ "${OS_FAMILY}" != "debian" ]]; then
    log_err "当前 install.sh 仅实现了 Debian/Ubuntu 自动依赖安装"
    exit 1
  fi

  export DEBIAN_FRONTEND=noninteractive

  local pkgs=()

  if ! command -v python3 >/dev/null 2>&1; then
    pkgs+=(python3)
  fi

  if ! python3 -m venv --help >/dev/null 2>&1; then
    pkgs+=(python3-venv)
  fi

  if ! python3 -m pip --version >/dev/null 2>&1; then
    pkgs+=(python3-pip)
  fi

  if ! command -v node >/dev/null 2>&1; then
    pkgs+=(nodejs)
  fi

  if ! command -v npm >/dev/null 2>&1; then
    pkgs+=(npm)
  fi

  if ! command -v curl >/dev/null 2>&1; then
    pkgs+=(curl)
  fi

  if ! command -v systemctl >/dev/null 2>&1; then
    pkgs+=(systemd)
  fi

  if ! dpkg -s ca-certificates >/dev/null 2>&1; then
    pkgs+=(ca-certificates)
  fi

  if [[ "${#pkgs[@]}" -gt 0 ]]; then
    log_info "安装系统依赖: ${pkgs[*]}"
    apt-get update -y
    apt-get install -y "${pkgs[@]}"
  else
    log_info "系统依赖已齐全，跳过安装"
  fi
}

load_existing_config() {
  if [[ -f "${CONFIG_FILE}" ]]; then
    # shellcheck disable=SC1090
    source "${CONFIG_FILE}" || true
  fi
}

prompt_api_port() {
  if [[ -n "${CLI_PORT_SET:-}" ]]; then
    return
  fi

  local input_port=""
  while true; do
    read_tty "请输入服务端口 [${APIPORT}]: " input_port
    input_port="${input_port:-${APIPORT}}"

    if [[ ! "${input_port}" =~ ^[0-9]+$ ]]; then
      log_err "端口必须为数字"
      continue
    fi

    if (( input_port < 1 || input_port > 65535 )); then
      log_err "端口范围必须在 1-65535 之间"
      continue
    fi

    APIPORT="${input_port}"
    break
  done
}

# ========== 修正后的 prompt_ui_pass（保留已有密码选项）==========
prompt_ui_pass() {
  if [[ -n "${UIPASS}" ]]; then
    local keep_old=""
    read_tty "检测到已有 UI 密码，是否保留？(Y/n): " keep_old
    keep_old="${keep_old:-Y}"

    if [[ "${keep_old}" =~ ^[Yy] ]]; then
      return
    fi
  fi

  while true; do
    read_tty "请设置 UI 登录密码(至少6位): " pass1
    if [[ ${#pass1} -lt 6 ]]; then
      log_err "密码至少 6 位"
      continue
    fi

    read_tty "请再次输入 UI 登录密码: " pass2
    if [[ "${pass1}" != "${pass2}" ]]; then
      log_err "两次输入不一致"
      continue
    fi

    UIPASS="${pass1}"
    break
  done
}
# ========================================================

check_port() {
  local port="$1"
  if ss -ltn 2>/dev/null | grep -q ":${port} "; then
    log_warn "端口 ${port} 已被占用"
    ss -ltnp 2>/dev/null | grep ":${port} " || true
    return 1
  fi
  return 0
}

write_config() {
  mkdir -p "$(dirname "${CONFIG_FILE}")"
  cat > "${CONFIG_FILE}" <<EOF
APPDIR="${APPDIR}"
APIPORT="${APIPORT}"
SCANUSER="${SCANUSER}"
SCANPASS="${SCANPASS}"
UIPASS="${UIPASS}"
EOF
  chmod 600 "${CONFIG_FILE}"
}

install_backend() {
  title "安装后端"

  mkdir -p "${APPDIR}/app" "${APPDIR}/data"

  if [[ ! -x "${APPDIR}/venv/bin/python" ]]; then
    rm -rf "${APPDIR}/venv"
    python3 -m venv "${APPDIR}/venv"
  fi

  "${APPDIR}/venv/bin/pip" install --upgrade pip
  "${APPDIR}/venv/bin/pip" install -r "${ROOT_DIR}/backend/requirements.txt"

  cp "${ROOT_DIR}/backend/main.py" "${APPDIR}/app/main.py"
}

install_frontend() {
  title "安装前端"

  rm -rf "${APPDIR}/static"
  mkdir -p "${APPDIR}/static"

  cd "${ROOT_DIR}/frontend"
  npm install
  npm run build

  cp -a "${ROOT_DIR}/frontend/dist/." "${APPDIR}/static/"
}

render_service() {
  local template="$1"
  local output="$2"

  sed \
    -e "s|{{APPDIR}}|${APPDIR}|g" \
    -e "s|{{APIPORT}}|${APIPORT}|g" \
    -e "s|{{SCANUSER}}|${SCANUSER}|g" \
    -e "s|{{SCANPASS}}|${SCANPASS}|g" \
    -e "s|{{UIPASS}}|${UIPASS}|g" \
    "${template}" > "${output}"
}

show_service_failure_logs() {
  journalctl -u board-manager-v4 -u board-manager-v6 -n 80 --no-pager || true
}

install_services() {
  title "安装 systemd 服务"

  render_service "${ROOT_DIR}/systemd/board-manager-v4.service" "/etc/systemd/system/board-manager-v4.service"
  render_service "${ROOT_DIR}/systemd/board-manager-v6.service" "/etc/systemd/system/board-manager-v6.service"

  systemctl daemon-reload
  systemctl enable board-manager-v4 board-manager-v6
  systemctl restart board-manager-v4 board-manager-v6

  if ! systemctl is-active --quiet board-manager-v4; then
    log_err "board-manager-v4 启动失败"
    show_service_failure_logs
    exit 1
  fi

  if ! systemctl is-active --quiet board-manager-v6; then
    log_err "board-manager-v6 启动失败"
    show_service_failure_logs
    exit 1
  fi
}

get_ipv4_info() {
  ip -4 -o addr show scope global 2>/dev/null | awk '{print $2 " " $4}'
}

get_ipv6_info() {
  ip -6 -o addr show scope global 2>/dev/null | awk '{print $2 " " $4}'
}

get_primary_ipv4() {
  ip route get 1.1.1.1 2>/dev/null | awk '/src/ {for(i=1;i<=NF;i++) if ($i=="src") print $(i+1)}' | head -n1
}

show_network_info() {
  local ipv4_lines ipv6_lines
  ipv4_lines="$(get_ipv4_info || true)"
  ipv6_lines="$(get_ipv6_info || true)"

  title "检测到本机网络信息"

  if [[ -n "${ipv4_lines}" ]]; then
    echo "${ipv4_lines}" | while read -r line; do
      [[ -n "${line}" ]] && log_info "IPv4: ${line}"
    done
  else
    log_warn "未检测到全局 IPv4 地址"
  fi

  if [[ -n "${ipv6_lines}" ]]; then
    echo "${ipv6_lines}" | while read -r line; do
      [[ -n "${line}" ]] && log_info "IPv6: ${line}"
    done
  else
    log_warn "未检测到全局 IPv6 地址"
  fi
}

show_result() {
  local ip
  ip="$(get_primary_ipv4 || true)"

  echo ""
  title "安装完成"
  log_info "程序目录: ${APPDIR}"
  log_info "配置文件: ${CONFIG_FILE}"
  log_info "服务端口: ${APIPORT}"
  log_info "扫描账号: ${SCANUSER}"

  if [[ -n "${ip}" ]]; then
    log_info "推荐访问地址: http://${ip}:${APIPORT}/"
  else
    log_info "推荐访问地址: http://127.0.0.1:${APIPORT}/"
  fi

  local ipv4_lines ipv6_lines
  ipv4_lines="$(get_ipv4_info || true)"
  ipv6_lines="$(get_ipv6_info || true)"

  if [[ -n "${ipv4_lines}" ]]; then
    echo "${ipv4_lines}" | while read -r line; do
      [[ -n "${line}" ]] && log_info "可用 IPv4: ${line}"
    done
  fi

  if [[ -n "${ipv6_lines}" ]]; then
    echo "${ipv6_lines}" | while read -r line; do
      [[ -n "${line}" ]] && log_info "可用 IPv6: ${line}"
    done
  fi
}

show_status() {
  systemctl status board-manager-v4 --no-pager || true
  systemctl status board-manager-v6 --no-pager || true
}

restart_services() {
  systemctl restart board-manager-v4 board-manager-v6
  show_status
}

show_logs() {
  journalctl -u board-manager-v4 -u board-manager-v6 -n 100 --no-pager
}

cmd="${1:-}"
CLI_PORT_SET=""

load_existing_config

shift || true

while [[ $# -gt 0 ]]; do
  case "$1" in
    --port)
      APIPORT="$2"
      CLI_PORT_SET=1
      shift 2
      ;;
    --scan-user)
      SCANUSER="$2"
      shift 2
      ;;
    --scan-pass)
      SCANPASS="$2"
      shift 2
      ;;
    --ui-pass)
      UIPASS="$2"
      shift 2
      ;;
    *)
      shift
      ;;
  esac
done

case "${cmd}" in
  install)
    need_root
    install_system_deps
    show_network_info
    prompt_api_port
    prompt_ui_pass
    check_port "${APIPORT}" || exit 1
    write_config
    install_backend
    install_frontend
    install_services
    show_result
    ;;
  status)
    need_root
    show_status
    ;;
  restart)
    need_root
    restart_services
    ;;
  logs)
    need_root
    show_logs
    ;;
  *)
    usage
    exit 1
    ;;
esac